﻿using System;
using System.Collections.Generic;

namespace P13.Models
{
    public partial class Adummy
    {
        public int Id { get; set; }
    }
}
